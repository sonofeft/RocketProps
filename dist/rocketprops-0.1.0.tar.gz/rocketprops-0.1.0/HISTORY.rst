.. commit signature, "date_str author_str sha_str"
   Maintain spacing of "History" and "GitHub Log" titles

History
=======

GitHub Log
----------


* Jul 22, 2020
    - (by: sonofeft)
        - First Created RocketProps with PyHatch

