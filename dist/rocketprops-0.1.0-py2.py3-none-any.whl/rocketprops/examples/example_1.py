"""
This example demonstrates the proper use of project: rocketprops
"""
import sys
import os

sys.path.insert(0, os.path.abspath("../../"))  # needed to find rocketprops development version

from rocketprops.rocket_prop import Propellant

# TODO: create working example of project rocketprops

my_class = Propellant()

